const board = document.getElementById("board");
const status = document.getElementById("status");
const resetBtn = document.getElementById("reset");
const modeSelect = document.getElementById("mode");
const difficultySelect = document.getElementById("difficulty");

let currentPlayer = "X";
let gameActive = true;
let gameState = ["", "", "", "", "", "", "", "", ""];

const winningConditions = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
];

function createBoard() {
  board.innerHTML = "";
  gameState = ["", "", "", "", "", "", "", "", ""];
  gameActive = true;
  currentPlayer = "X";
  status.textContent = `Player ${currentPlayer}'s turn`;

  for (let i = 0; i < 9; i++) {
    const cell = document.createElement("div");
    cell.classList.add("cell");
    cell.setAttribute("data-index", i);
    cell.addEventListener("click", handleCellClick);
    board.appendChild(cell);
  }
}

function handleCellClick(e) {
  const index = e.target.getAttribute("data-index");

  if (gameState[index] !== "" || !gameActive) return;

  makeMove(index, currentPlayer);

  if (checkWinner()) {
    status.textContent = `🎉 Player ${currentPlayer} wins! 🎉`;
    gameActive = false;
    return;
  }

  if (!gameState.includes("")) {
    status.textContent = "🤝 It's a draw!";
    gameActive = false;
    return;
  }

  currentPlayer = currentPlayer === "X" ? "O" : "X";
  status.textContent = `Player ${currentPlayer}'s turn`;

  if (modeSelect.value === "cpu" && currentPlayer === "O" && gameActive) {
    setTimeout(cpuMove, 500);
  }
}

function makeMove(index, player) {
  gameState[index] = player;
  const cell = board.querySelector(`[data-index='${index}']`);
  cell.textContent = player;
}

function checkWinner() {
  return winningConditions.some(condition => {
    const [a, b, c] = condition;
    return (
      gameState[a] &&
      gameState[a] === gameState[b] &&
      gameState[a] === gameState[c]
    );
  });
}

function cpuMove() {
  let move;
  if (difficultySelect.value === "easy") {
    const available = gameState.map((val, i) => (val === "" ? i : null)).filter(v => v !== null);
    move = available[Math.floor(Math.random() * available.length)];
  } else {
    move = minimax(gameState, "O").index;
  }
  makeMove(move, "O");

  if (checkWinner()) {
    status.textContent = `🤖 Player O wins!`;
    gameActive = false;
    return;
  }

  if (!gameState.includes("")) {
    status.textContent = "🤝 It's a draw!";
    gameActive = false;
    return;
  }

  currentPlayer = "X";
  status.textContent = `Player ${currentPlayer}'s turn`;
}

function minimax(newBoard, player) {
  const availSpots = newBoard.map((v, i) => (v === "" ? i : null)).filter(v => v !== null);

  if (checkWin(newBoard, "X")) return { score: -10 };
  if (checkWin(newBoard, "O")) return { score: 10 };
  if (availSpots.length === 0) return { score: 0 };

  let moves = [];
  for (let i = 0; i < availSpots.length; i++) {
    let move = {};
    move.index = availSpots[i];
    newBoard[availSpots[i]] = player;

    if (player === "O") {
      move.score = minimax(newBoard, "X").score;
    } else {
      move.score = minimax(newBoard, "O").score;
    }

    newBoard[availSpots[i]] = "";
    moves.push(move);
  }

  let bestMove;
  if (player === "O") {
    let bestScore = -10000;
    for (let i = 0; i < moves.length; i++) {
      if (moves[i].score > bestScore) {
        bestScore = moves[i].score;
        bestMove = i;
      }
    }
  } else {
    let bestScore = 10000;
    for (let i = 0; i < moves.length; i++) {
      if (moves[i].score < bestScore) {
        bestScore = moves[i].score;
        bestMove = i;
      }
    }
  }
  return moves[bestMove];
}

function checkWin(boardState, player) {
  return winningConditions.some(cond => cond.every(i => boardState[i] === player));
}

resetBtn.addEventListener("click", createBoard);

createBoard();
window.addEventListener("load", () => {
  const splash = document.getElementById("splash-screen");
  const app = document.querySelector(".app");

  setTimeout(() => {
    splash.style.display = "none";
    app.style.display = "block";
  }, 4000); // 4 seconds splash
});
window.addEventListener("load", () => {
  const splash = document.getElementById("splash-screen");
  const app = document.querySelector(".app");
  const introMusic = document.getElementById("intro-music");

  // Play music at splash
  introMusic.play().catch(err => console.log("Autoplay blocked:", err));

  setTimeout(() => {
    splash.style.display = "none";
    app.style.display = "block";
    introMusic.pause();
    introMusic.currentTime = 0; // reset
  }, 4000); // 4 seconds splash
});
window.addEventListener("load", () => {
  const splash = document.getElementById("splash-screen");
  const app = document.querySelector(".app");
  const introMusic = document.getElementById("intro-music");
  const bgMusic = document.getElementById("bg-music");
  const muteBtn = document.getElementById("muteBtn");

  // Play splash intro music
  introMusic.play().catch(err => console.log("Autoplay blocked:", err));

  setTimeout(() => {
    splash.style.display = "none";
    app.style.display = "block";

    // Stop intro, start background loop
    introMusic.pause();
    introMusic.currentTime = 0;
    bgMusic.play().catch(err => console.log("Autoplay blocked:", err));
  }, 4000);

  // Toggle mute/unmute
  muteBtn.addEventListener("click", () => {
    if (bgMusic.muted) {
      bgMusic.muted = false;
      muteBtn.textContent = "🔊";
    } else {
      bgMusic.muted = true;
      muteBtn.textContent = "🔇";
    }
  });
});
const clickSound = document.getElementById("click-sound");
const winSound = document.getElementById("win-sound");
const drawSound = document.getElementById("draw-sound");

// When player makes a move
function handleMove(cell) {
  if (cell.textContent === "") {
    cell.textContent = currentPlayer;
    clickSound.currentTime = 0;
    clickSound.play();
    checkGameStatus();
    switchTurn();
  }
}

// After checking win/draw
function checkGameStatus() {
  const winner = checkWinner();
  if (winner) {
    document.getElementById("turn").textContent = `${winner} Wins!`;
    winSound.currentTime = 0;
    winSound.play();
    updateScores(winner);
    return true;
  } else if (isDraw()) {
    document.getElementById("turn").textContent = "It's a Draw!";
    drawSound.currentTime = 0;
    drawSound.play();
    updateScores("D");
    return true;
  }
  return false;
}
clickSound.volume = 0.5;
winSound.volume = 0.8;
drawSound.volume = 0.6;
const boardContainer = document.querySelector(".board-container");

function drawWinningLine(combo) {
  const line = document.createElement("div");
  line.classList.add("winning-line");

  const cells = document.querySelectorAll(".cell");
  const firstCell = cells[combo[0]].getBoundingClientRect();
  const lastCell = cells[combo[2]].getBoundingClientRect();
  const boardRect = boardContainer.getBoundingClientRect();

  const x1 = firstCell.left + firstCell.width / 2 - boardRect.left;
  const y1 = firstCell.top + firstCell.height / 2 - boardRect.top;
  const x2 = lastCell.left + lastCell.width / 2 - boardRect.left;
  const y2 = lastCell.top + lastCell.height / 2 - boardRect.top;

  const length = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
  const angle = Math.atan2(y2 - y1, x2 - x1) * (180 / Math.PI);

  line.style.width = `${length}px`;
  line.style.transform = `rotate(${angle}deg)`;
  line.style.top = `${y1}px`;
  line.style.left = `${x1}px`;

  boardContainer.appendChild(line);
}
function checkGameStatus() {
  const winnerData = checkWinner(); // should return {player, combo}
  if (winnerData) {
    document.getElementById("turn").textContent = `${winnerData.player} Wins!`;
    winSound.currentTime = 0;
    winSound.play();
    drawWinningLine(winnerData.combo); // <--- show animation
    updateScores(winnerData.player);
    launchConfetti(); // optional
    return true;
  } else if (isDraw()) {
    document.getElementById("turn").textContent = "It's a Draw!";
    drawSound.currentTime = 0;
    drawSound.play();
    updateScores("D");
    return true;
  }
  return false;
}
function launchConfetti() {
  confetti({
    particleCount: 150,
    spread: 70,
    origin: { y: 0.6 }
  });
}
function resetBoard() {
  const board = document.getElementById("board");
  const cells = document.querySelectorAll(".cell");

  // Add shake effect
  board.style.animation = "shake 0.5s";

  // After shake, fade out
  setTimeout(() => {
    board.classList.add("fade-out");

    // After fade out, clear cells & remove winning lines
    setTimeout(() => {
      cells.forEach(cell => (cell.textContent = ""));
      const line = document.querySelector(".winning-line");
      if (line) line.remove();

      // Fade back in
      board.classList.remove("fade-out");
      board.classList.add("fade-in");

      // Reset turn text
      document.getElementById("turn").textContent = "Player X's turn";

      // Remove animation classes after transition
      setTimeout(() => {
        board.classList.remove("fade-in");
        board.style.animation = "";
      }, 500);

    }, 500); // Wait for fade out

  }, 500); // Wait for shake
}
function resetBoard() {
  const board = document.getElementById("board");
  const cells = document.querySelectorAll(".cell");

  // Shake animation
  board.style.animation = "shake 0.5s";

  // After shake, fade out
  setTimeout(() => {
    board.classList.add("fade-out");

    setTimeout(() => {
      // Clear cells & remove winning lines
      cells.forEach(cell => (cell.textContent = ""));
      const line = document.querySelector(".winning-line");
      if (line) line.remove();

      // Fade in
      board.classList.remove("fade-out");
      board.classList.add("fade-in");

      // Reset turn text
      document.getElementById("turn").textContent = "Player X's turn";

      // 🎇 Restart Celebration Sparkles
      setTimeout(() => {
        confetti({
          particleCount: 80,
          spread: 90,
          origin: { y: 0.8 },
          colors: ["#ff0", "#0ff", "#f0f", "#ff6600"]
        });
        board.classList.remove("fade-in");
        board.style.animation = "";
      }, 500);

    }, 500); // fade out duration
  }, 500); // shake duration
}
window.addEventListener("load", () => {
  const splash = document.getElementById("splash-screen");
  const game = document.getElementById("game-container");

  setTimeout(() => {
    // Confetti before transition
    confetti({
      particleCount: 120,
      spread: 100,
      origin: { y: 0.6 },
      colors: ["#ff0", "#0ff", "#f0f", "#ff6600"]
    });

    // Fade out splash
    splash.style.animation = "fadeOut 1s forwards";

    // Show game after splash fades
    setTimeout(() => {
      splash.style.display = "none";
      game.style.display = "block";
    }, 1000);

  }, 2500); // Splash stays for 2.5s
});
window.addEventListener("load", () => {
  const splash = document.getElementById("splash-screen");
  const game = document.getElementById("game-container");
  const bgMusic = document.getElementById("bg-music");
  const musicToggle = document.getElementById("music-toggle");

  setTimeout(() => {
    confetti({
      particleCount: 120,
      spread: 100,
      origin: { y: 0.6 },
      colors: ["#ff0", "#0ff", "#f0f", "#ff6600"]
    });

    splash.style.animation = "fadeOut 1s forwards";

    setTimeout(() => {
      splash.style.display = "none";
      game.style.display = "block";

      // 🎶 Start background music
      bgMusic.volume = 0.5; 
      bgMusic.play().catch(err => console.log("Autoplay blocked:", err));

    }, 1000);
  }, 2500);

  // 🎵 Music toggle button
  musicToggle.addEventListener("click", () => {
    if (bgMusic.paused) {
      bgMusic.play();
      musicToggle.textContent = "🔊 Music On";
    } else {
      bgMusic.pause();
      musicToggle.textContent = "🔇 Music Off";
    }
  });
});
const popSound = document.getElementById("pop-sound");
const winSound = document.getElementById("win-sound");
const drawSound = document.getElementById("draw-sound");
if (cell.textContent === "") {
  cell.textContent = currentPlayer;
  popSound.currentTime = 0; 
  popSound.play();
}
if (winner) {
  winSound.currentTime = 0;
  winSound.play();
  document.getElementById("turn").textContent = `🎉 Player ${winner} Wins! 🎉`;
}
if (isDraw) {
  drawSound.currentTime = 0;
  drawSound.play();
  document.getElementById("turn").textContent = "😅 It's a Draw!";
}
if (winner) {
  winSound.currentTime = 0;
  winSound.play();

  document.getElementById("turn").textContent = `🎉 Player ${winner} Wins! 🎉`;

  // Highlight winning cells
  winningCombo.forEach(index => {
    document.querySelectorAll(".cell")[index].classList.add("win-cell");
  });

  // Shake the board
  const board = document.getElementById("board");
  board.classList.add("board-shake");

  // Remove shake effect after animation
  setTimeout(() => {
    board.classList.remove("board-shake");
  }, 2000);
}
if (winner) {
  winSound.currentTime = 0;
  winSound.play();

  document.getElementById("turn").textContent = `🎉 Player ${winner} Wins! 🎉`;

  // Highlight winning cells
  winningCombo.forEach(index => {
    document.querySelectorAll(".cell")[index].classList.add("win-cell");
  });

  // Shake the board
  const board = document.getElementById("board");
  board.classList.add("board-shake");

  setTimeout(() => {
    board.classList.remove("board-shake");
  }, 2000);

  // 🎇 Confetti Explosion
  let duration = 2 * 1000; // 2 seconds
  let end = Date.now() + duration;

  (function frame() {
    confetti({
      particleCount: 8,
      startVelocity: 30,
      spread: 360,
      origin: { x: Math.random(), y: Math.random() - 0.2 }
    });
    if (Date.now() < end) {
      requestAnimationFrame(frame);
    }
  })();
}
if (isDraw) {
  drawSound.currentTime = 0;
  drawSound.play();

  document.getElementById("turn").textContent = "😅 It's a Draw!";

  // 🎇 Silver & Blue Confetti
  let duration = 2 * 1000;
  let end = Date.now() + duration;

  (function frame() {
    confetti({
      particleCount: 6,
      spread: 180,
      startVelocity: 25,
      colors: ['#00f', '#0ff', '#aaa', '#fff'],
      origin: { x: Math.random(), y: Math.random() - 0.2 }
    });
    if (Date.now() < end) {
      requestAnimationFrame(frame);
    }
  })();
}
function restartGame() {
  // Play restart sound
  const restartSound = document.getElementById("restart-sound");
  if (restartSound) {
    restartSound.currentTime = 0;
    restartSound.play();
  }

  // Flash effect
  const board = document.getElementById("board");
  board.classList.add("flash-effect");

  setTimeout(() => {
    board.classList.remove("flash-effect");
  }, 500);

  // Quick confetti burst 🎆
  confetti({
    particleCount: 30,
    spread: 90,
    origin: { y: 0.6 }
  });

  // Reset board cells
  document.querySelectorAll(".cell").forEach(cell => {
    cell.textContent = "";
    cell.classList.remove("win-cell");
  });

  // Reset turn
  currentPlayer = "X";
  document.getElementById("turn").textContent = "Player X's Turn";
}
const cells = document.querySelectorAll(".cell");
const turnText = document.getElementById("turn");
const restartBtn = document.getElementById("restart");

let currentPlayer = "X";
let board = Array(9).fill("");

const winSound = document.getElementById("win-sound");
const drawSound = document.getElementById("draw-sound");
const restartSound = document.getElementById("restart-sound");

const winPatterns = [
  [0,1,2], [3,4,5], [6,7,8], // rows
  [0,3,6], [1,4,7], [2,5,8], // cols
  [0,4,8], [2,4,6]           // diagonals
];

cells.forEach(cell => {
  cell.addEventListener("click", () => {
    const index = cell.dataset.index;

    if (board[index] !== "" || checkWinner()) return;

    board[index] = currentPlayer;
    cell.textContent = currentPlayer;

    if (checkWinner()) {
      handleWin(currentPlayer);
    } else if (board.every(cell => cell !== "")) {
      handleDraw();
    } else {
      currentPlayer = currentPlayer === "X" ? "O" : "X";
      turnText.textContent = `Player ${currentPlayer}'s Turn`;
    }
  });
});

restartBtn.addEventListener("click", restartGame);

function checkWinner() {
  for (let pattern of winPatterns) {
    const [a, b, c] = pattern;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return pattern;
    }
  }
  return null;
}

function handleWin(player) {
  winSound.currentTime = 0;
  winSound.play();

  turnText.textContent = `🎉 Player ${player} Wins! 🎉`;

  const winningCombo = checkWinner();
  winningCombo.forEach(index => {
    cells[index].classList.add("win-cell");
  });

  // Shake board
  const boardEl = document.getElementById("board");
  boardEl.classList.add("board-shake");
  setTimeout(() => boardEl.classList.remove("board-shake"), 2000);

  // Confetti Explosion
  let duration = 2 * 1000;
  let end = Date.now() + duration;

  (function frame() {
    confetti({
      particleCount: 8,
      startVelocity: 30,
      spread: 360,
      origin: { x: Math.random(), y: Math.random() - 0.2 }
    });
    if (Date.now() < end) requestAnimationFrame(frame);
  })();
}

function handleDraw() {
  drawSound.currentTime = 0;
  drawSound.play();

  turnText.textContent = "😅 It's a Draw!";

  let duration = 2 * 1000;
  let end = Date.now() + duration;

  (function frame() {
    confetti({
      particleCount: 6,
      spread: 180,
      startVelocity: 25,
      colors: ['#00f', '#0ff', '#aaa', '#fff'],
      origin: { x: Math.random(), y: Math.random() - 0.2 }
    });
    if (Date.now() < end) requestAnimationFrame(frame);
  })();
}

function restartGame() {
  restartSound.currentTime = 0;
  restartSound.play();

  const boardEl = document.getElementById("board");
  boardEl.classList.add("flash-effect");
  setTimeout(() => boardEl.classList.remove("flash-effect"), 500);

  confetti({
    particleCount: 30,
    spread: 90,
    origin: { y: 0.6 }
  });

  board = Array(9).fill("");
  cells.forEach(cell => {
    cell.textContent = "";
    cell.classList.remove("win-cell");
  });

  currentPlayer = "X";
  turnText.textContent = "Player X's Turn";
}
const soundToggleBtn = document.getElementById("sound-toggle");
let soundEnabled = true;

function updateSoundButton() {
  soundToggleBtn.textContent = soundEnabled ? "🔊 Sound: ON" : "🔇 Sound: OFF";
}

// Toggle button click
soundToggleBtn.addEventListener("click", () => {
  soundEnabled = !soundEnabled;
  updateSoundButton();
  
  // Control all <audio> elements
  document.querySelectorAll("audio").forEach(audio => {
    audio.muted = !soundEnabled;
  });
});

// Initialize button text
updateSoundButton();
window.addEventListener("load", () => {
  const splashMusic = document.getElementById("splash-music");
  const bgMusic = document.getElementById("bg-music");
  splashMusic.volume = 0.6;
  bgMusic.volume = 0.4;

  splashMusic.play();

  setTimeout(() => {
    document.getElementById("splash").classList.add("fade-out");
    splashMusic.pause();
    splashMusic.currentTime = 0;

    setTimeout(() => {
      document.getElementById("splash").style.display = "none";
      document.getElementById("game").classList.remove("hidden");
      if (soundEnabled) bgMusic.play();
    }, 1000);
  }, 3000);
});
const volumeSlider = document.getElementById("volume-slider");

// Update all audio volumes when slider changes
volumeSlider.addEventListener("input", () => {
  const volume = parseFloat(volumeSlider.value);
  document.querySelectorAll("audio").forEach(audio => {
    audio.volume = volume;
  });
});
const musicSlider = document.getElementById("music-slider");
const sfxSlider = document.getElementById("sfx-slider");

// Update music volume
musicSlider.addEventListener("input", () => {
  const volume = parseFloat(musicSlider.value);
  document.querySelectorAll("#bg-music, #splash-music").forEach(audio => {
    audio.volume = volume;
  });
});

// Update sound effects volume
sfxSlider.addEventListener("input", () => {
  const volume = parseFloat(sfxSlider.value);
  document.querySelectorAll("#win-sound, #draw-sound, #restart-sound").forEach(audio => {
    audio.volume = volume;
  });
});

// Initialize default volumes
musicSlider.dispatchEvent(new Event("input"));
sfxSlider.dispatchEvent(new Event("input"));
const soundToggleBtn = document.getElementById("sound-toggle");
const musicSlider = document.getElementById("music-slider");
const sfxSlider = document.getElementById("sfx-slider");

let soundEnabled = true;

// 🔹 Load saved settings
function loadSettings() {
  const savedSound = localStorage.getItem("soundEnabled");
  const savedMusicVol = localStorage.getItem("musicVolume");
  const savedSfxVol = localStorage.getItem("sfxVolume");

  if (savedSound !== null) {
    soundEnabled = savedSound === "true";
    document.querySelectorAll("audio").forEach(audio => {
      audio.muted = !soundEnabled;
    });
  }

  if (savedMusicVol !== null) {
    musicSlider.value = savedMusicVol;
  }
  if (savedSfxVol !== null) {
    sfxSlider.value = savedSfxVol;
  }

  updateSoundButton();
  applyVolumes();
}

// 🔹 Save settings
function saveSettings() {
  localStorage.setItem("soundEnabled", soundEnabled);
  localStorage.setItem("musicVolume", musicSlider.value);
  localStorage.setItem("sfxVolume", sfxSlider.value);
}

// 🔹 Apply volumes
function applyVolumes() {
  const musicVol = parseFloat(musicSlider.value);
  const sfxVol = parseFloat(sfxSlider.value);

  document.querySelectorAll("#bg-music, #splash-music").forEach(audio => {
    audio.volume = musicVol;
  });

  document.querySelectorAll("#win-sound, #draw-sound, #restart-sound").forEach(audio => {
    audio.volume = sfxVol;
  });
}

// 🔹 Toggle button logic
function updateSoundButton() {
  soundToggleBtn.textContent = soundEnabled ? "🔊 Sound: ON" : "🔇 Sou
const resetBtn = document.getElementById("reset-settings");

resetBtn.addEventListener("click", () => {
  // Default values
  soundEnabled = true;
  musicSlider.value = 0.6;
  sfxSlider.value = 0.8;

  // Apply
  document.querySelectorAll("audio").forEach(audio => {
    audio.muted = false;
  });

  updateSoundButton();
  applyVolumes();
  saveSettings();

  alert("Sound settings reset to default 🎶🔔");
});
// Modal elements
const settingsModal = document.getElementById("settings-modal");
const openSettingsBtn = document.getElementById("open-settings");
const closeSettingsBtn = document.getElementById("close-settings");

// Open modal
openSettingsBtn.addEventListener("click", () => {
  settingsModal.style.display = "flex";
});

// Close modal
closeSettingsBtn.addEventListener("click", () => {
  settingsModal.style.display = "none";
});

// Close when clicking outside modal
window.addEventListener("click", (e) => {
  if (e.target === settingsModal) {
    settingsModal.style.display = "none";
  }
});
const themeToggleBtn = document.getElementById("theme-toggle");

// Load saved theme
function loadTheme() {
  const savedTheme = localStorage.getItem("theme") || "dark";
  if (savedTheme === "light") {
    document.body.classList.remove("dark-theme");
    document.body.classList.add("light-theme");
    themeToggleBtn.textContent = "🌙 Dark Theme";
  } else {
    document.body.classList.remove("light-theme");
    document.body.classList.add("dark-theme");
    themeToggleBtn.textContent = "☀️ Light Theme";
  }
}

// Save theme
function saveTheme(theme) {
  localStorage.setItem("theme", theme);
}

// Toggle theme
themeToggleBtn.addEventListener("click", () => {
  if (document.body.classList.contains("dark-theme")) {
    document.body.classList.remove("dark-theme");
    document.body.classList.add("light-theme");
    themeToggleBtn.textContent = "🌙 Dark Theme";
    saveTheme("light");
  } else {
    document.body.classList.remove("light-theme");
    document.body.classList.add("dark-theme");
    themeToggleBtn.textContent = "☀️ Light Theme";
    saveTheme("dark");
  }
});

// Initialize theme on page load
loadTheme();
function loadTheme() {
  const savedTheme = localStorage.getItem("theme") || "dark";
  if (savedTheme === "light") {
    applyLightTheme();
  } else {
    applyDarkTheme();
  }
}

function applyDarkTheme() {
  document.body.classList.remove("light-theme");
  document.body.classList.add("dark-theme");
  themeToggleBtn.textContent = "☀️ Light Theme";
  saveTheme("dark");
}

function applyLightTheme() {
  document.body.classList.remove("dark-theme");
  document.body.classList.add("light-theme");
  themeToggleBtn.textContent = "🌙 Dark Theme";
  saveTheme("light");
}

themeToggleBtn.addEventListener("click", () => {
  if (document.body.classList.contains("dark-theme")) {
    applyLightTheme();
  } else {
    applyDarkTheme();
  }
});

loadTheme();
function handleCellClick(e) {
  const cell = e.target;
  if (cell.textContent !== "") return;

  cell.textContent = currentPlayer;
  cell.classList.add(currentPlayer.toLowerCase()); // <-- Add X or O class

  if (checkWin(currentPlayer)) {
    setTimeout(() => {
      alert(`${currentPlayer} wins!`);
      resetBoard();
    }, 100);
  } else if ([...cells].every(c => c.textContent !== "")) {
    setTimeout(() => {
      alert("It's a draw!");
      resetBoard();
    }, 100);
  } else {
    currentPlayer = currentPlayer === "X" ? "O" : "X";
  }
}

function resetBoard() {
  cells.forEach(cell => {
    cell.textContent = "";
    cell.classList.remove("x", "o"); // <-- Reset classes
  });
  currentPlayer = "X";
}
function checkWin(player) {
  const winningCombos = [
    [0,1,2], [3,4,5], [6,7,8], // rows
    [0,3,6], [1,4,7], [2,5,8], // cols
    [0,4,8], [2,4,6]           // diagonals
  ];

  for (let combo of winningCombos) {
    if (combo.every(index => cells[index].textContent === player)) {
      // Highlight winning cells
      combo.forEach(index => cells[index].classList.add("win"));
      return true;
    }
  }
  return false;
}

function resetBoard() {
  cells.forEach(cell => {
    cell.textContent = "";
    cell.classList.remove("x", "o", "win"); // remove win class too
  });
  currentPlayer = "X";
}
// Confetti Setup
const confettiCanvas = document.getElementById("confetti-canvas");
const ctx = confettiCanvas.getContext("2d");
confettiCanvas.width = window.innerWidth;
confettiCanvas.height = window.innerHeight;

window.addEventListener("resize", () => {
  confettiCanvas.width = window.innerWidth;
  confettiCanvas.height = window.innerHeight;
});

// Confetti particles
let confetti = [];

function createConfetti() {
  const colors = ["#ff0077", "#00ffcc", "#ff6600", "#0077ff", "#ffff00"];
  for (let i = 0; i < 150; i++) {
    confetti.push({
      x: Math.random() * confettiCanvas.width,
      y: Math.random() * confettiCanvas.height - confettiCanvas.height,
      r: Math.random() * 6 + 2, // size
      d: Math.random() * 0.5 + 0.5, // density
      color: colors[Math.floor(Math.random() * colors.length)],
      tilt: Math.random() * 10 - 10,
      tiltAngleIncrement: Math.random() * 0.07 + 0.05,
      tiltAngle: 0,
    });
  }
}

function drawConfetti() {
  ctx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
  confetti.forEach((c, i) => {
    ctx.beginPath();
    ctx.lineWidth = c.r;
    ctx.strokeStyle = c.color;
    ctx.moveTo(c.x + c.tilt + c.r / 2, c.y);
    ctx.lineTo(c.x + c.tilt, c.y + c.tilt + c.r / 2);
    ctx.stroke();
  });

  updateConfetti();
}

function updateConfetti() {
  confetti.forEach((c, i) => {
    c.tiltAngle += c.tiltAngleIncrement;
    c.y += (Math.cos(c.d) + 3 + c.r / 2) / 2;
    c.x += Math.sin(c.d);
    c.tilt = Math.sin(c.tiltAngle - i / 3) * 15;

    if (c.y > confettiCanvas.height) {
      confetti[i] = {
        ...c,
        x: Math.random() * confettiCanvas.width,
        y: -20,
      };
    }
  });
}

function startConfetti() {
  createConfetti();
  let duration = 3000; // 3 sec
  let end = Date.now() + duration;

  (function frame() {
    drawConfetti();
    if (Date.now() < end) {
      requestAnimationFrame(frame);
    } else {
      confetti = []; // clear confetti
      ctx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
    }
  })();
}
if (checkWin(currentPlayer)) {
  setTimeout(() => {
    alert(`${currentPlayer} wins! 🎉`);
    startConfetti(); // <-- Celebration!
    resetBoard();
  }, 100);
}
const winnerModal = document.getElementById("winner-modal");
const winnerText = document.getElementById("winner-text");
const playAgainBtn = document.getElementById("play-again");

function showWinner(player) {
  winnerText.textContent = `${player} Wins! 🎉`;
  winnerModal.style.display = "flex"; // show modal
  startConfetti(); // celebration
}

// Handle play again
playAgainBtn.addEventListener("click", () => {
  winnerModal.style.display = "none";
  resetBoard();
});
if (checkWin(currentPlayer)) {
  setTimeout(() => {
    showWinner(currentPlayer); // show modal instead of alert
  }, 200);
}
let scoreX = 0;
let scoreO = 0;
let scoreDraw = 0;

const scoreXEl = document.getElementById("score-x");
const scoreOEl = document.getElementById("score-o");
const scoreDrawEl = document.getElementById("score-draw");
function showWinner(player) {
  if (player === "X") {
    scoreX++;
    scoreXEl.textContent = scoreX;
  } else if (player === "O") {
    scoreO++;
    scoreOEl.textContent = scoreO;
  }

  winnerText.textContent = `${player} Wins! 🎉`;
  winnerModal.style.display = "flex";
  startConfetti();
}
if (isDraw()) {
  scoreDraw++;
  scoreDrawEl.textContent = scoreDraw;

  winnerText.textContent = "It's a Draw 🤝";
  winnerModal.style.display = "flex";
}
const resetScoresBtn = document.getElementById("reset-scores");

resetScoresBtn.addEventListener("click", () => {
  scoreX = 0;
  scoreO = 0;
  scoreDraw = 0;

  scoreXEl.textContent = scoreX;
  scoreOEl.textContent = scoreO;
  scoreDrawEl.textContent = scoreDraw;
});
let targetWins = 5; // default Best of 5
const modeSelect = document.getElementById("mode");

modeSelect.addEventListener("change", () => {
  targetWins = parseInt(modeSelect.value);
  resetTournament();
});
function showWinner(player) {
  if (player === "X") {
    scoreX++;
    scoreXEl.textContent = scoreX;
  } else if (player === "O") {
    scoreO++;
    scoreOEl.textContent = scoreO;
  }

  // Check tournament winner
  if (scoreX === Math.ceil(targetWins / 2)) {
    winnerText.textContent = `❌ X is the Champion! 🏆 (Best of ${targetWins})`;
    winnerModal.style.display = "flex";
    startConfetti();
    resetTournamentAfterDelay();
    return;
  } else if (scoreO === Math.ceil(targetWins / 2)) {
    winnerText.textContent = `⭕ O is the Champion! 🏆 (Best of ${targetWins})`;
    winnerModal.style.display = "flex";
    startConfetti();
    resetTournamentAfterDelay();
    return;
  }

  winnerText.textContent = `${player} Wins! 🎉`;
  winnerModal.style.display = "flex";
  startConfetti();
}
if (isDraw()) {
  scoreDraw++;
  scoreDrawEl.textContent = scoreDraw;

  winnerText.textContent = "It's a Draw 🤝";
  winnerModal.style.display = "flex";
}
function resetTournament() {
  scoreX = 0;
  scoreO = 0;
  scoreDraw = 0;
  scoreXEl.textContent = scoreX;
  scoreOEl.textContent = scoreO;
  scoreDrawEl.textContent = scoreDraw;
}
function resetTournamentAfterDelay() {
  setTimeout(() => {
    resetTournament();
  }, 2500); // resets after 2.5 seconds
}
let seriesCount = 0;
const historyList = document.getElementById("history-list");
function resetTournamentAfterDelay() {
  setTimeout(() => {
    seriesCount++;

    let champion = "";
    if (scoreX > scoreO) {
      champion = `❌ X wins the series ${scoreX}-${scoreO}`;
    } else if (scoreO > scoreX) {
      champion = `⭕ O wins the series ${scoreO}-${scoreX}`;
    } else {
      champion = `🤝 Series ended in a Draw (${scoreX}-${scoreO})`;
    }

    const li = document.createElement("li");
    li.textContent = `Series ${seriesCount}: ${champion} (Best of ${targetWins})`;
    historyList.prepend(li); // newest first

    resetTournament();
  }, 2500);
}
let seriesCount = 0;
const historyList = document.getElementById("history-list");

// Load saved history
let savedHistory = JSON.parse(localStorage.getItem("seriesHistory")) || [];
let savedCount = localStorage.getItem("seriesCount") || 0;
seriesCount = parseInt(savedCount);

// Render saved history
savedHistory.forEach(entry => {
  const li = document.createElement("li");
  li.textContent = entry;
  historyList.appendChild(li);
});
function resetTournamentAfterDelay() {
  setTimeout(() => {
    seriesCount++;

    let champion = "";
    if (scoreX > scoreO) {
      champion = `❌ X wins the series ${scoreX}-${scoreO}`;
    } else if (scoreO > scoreX) {
      champion = `⭕ O wins the series ${scoreO}-${scoreX}`;
    } else {
      champion = `🤝 Series ended in a Draw (${scoreX}-${scoreO})`;
    }

    const record = `Series ${seriesCount}: ${champion} (Best of ${targetWins})`;

    // Add to UI
    const li = document.createElement("li");
    li.textContent = record;
    historyList.prepend(li);

    // Save to localStorage
    savedHistory.unshift(record); // newest first
    localStorage.setItem("seriesHistory", JSON.stringify(savedHistory));
    localStorage.setItem("seriesCount", seriesCount);

    resetTournament();
  }, 2500);
}
document.getElementById("clear-history").addEventListener("click", () => {
  localStorage.removeItem("seriesHistory");
  localStorage.removeItem("seriesCount");
  historyList.innerHTML = "";
  savedHistory = [];
  seriesCount = 0;
});
const { app, BrowserWindow } = require("electron");

function createWindow() {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: { nodeIntegration: true }
  });
  win.loadFile("index.html");
}

app.whenReady().then(createWindow);
# 📦 Electron Project for **Tic Tac with Tashan**

Below are all the files for a ready‑to‑run Electron desktop app. Put them in a new folder, keep the same structure, then run `npm install` and `npm start`.

---

## 📁 File Tree
```
.
├─ package.json
├─ main.js
├─ preload.js
├─ .gitignore
├─ assets/
│  ├─ icon.png              # (optional) app icon 512x512
│  └─ icon.icns             # (optional) macOS icon
└─ app/                     # your web game lives here
   ├─ index.html
   ├─ style.css
   ├─ script.js
   ├─ logo.png
   ├─ splash.mp3
   ├─ bg-music.mp3
   ├─ win.mp3
   ├─ draw.mp3
   └─ restart.mp3
```

> If you already have your game files, simply replace the files inside `app/` with your latest versions. The ones below are a working set that includes the splash screen, settings modal, sound system, theme toggle, scoreboard, best‑of‑N, and series history (with persistence).

---

## `package.json`
```json
{
  "name": "tic-tac-with-tashan",
  "version": "1.0.0",
  "description": "Tic Tac with Tashan – Electron desktop app",
  "main": "main.js",
  "author": "You",
  "license": "MIT",
  "scripts": {
    "start": "electron .",
    "dev": "electron .",
    "pack": "electron-builder --dir",
    "dist": "electron-builder"
  },
  "devDependencies": {
    "electron": "^31.0.0",
    "electron-builder": "^24.13.3"
  },
  "build": {
    "appId": "com.yourname.tictacwithtashan",
    "productName": "Tic Tac with Tashan",
    "files": [
      "app/**/*",
      "main.js",
      "preload.js",
      "package.json"
    ],
    "extraResources": [
      {
        "from": "assets/",
        "to": "assets",
        "filter": ["**/*"]
      }
    ],
    "mac": {
      "icon": "assets/icon.icns"
    },
    "win": {
      "icon": "assets/icon.png",
      "target": ["nsis", "portable"]
    },
    "linux": {
      "icon": "assets/icon.png",
      "target": ["AppImage", "deb"]
    }
  }
}
```

---

## `main.js`
```js
const { app, BrowserWindow, shell, nativeTheme } = require('electron');
const path = require('path');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1024,
    height: 768,
    minWidth: 820,
    minHeight: 600,
    backgroundColor: nativeTheme.shouldUseDarkColors ? '#111111' : '#f9f9f9',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.removeMenu();
  mainWindow.loadFile(path.join(__dirname, 'app', 'index.html'));

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => { mainWindow = null; });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
```

---

## `preload.js`
```js
// Minimal, but ready if you want to expose APIs later
const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('tashan', {
  version: '1.0.0'
});
```

---

## `.gitignore`
```gitignore
node_modules
/dist
/out
/build
.DS_Store
```

---

# 🕹 Web App (in `app/`)

## `app/index.html`
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tic Tac with Tashan</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body class="dark-theme">
  <!-- # 📦 Electron Project for **Tic Tac with Tashan**

Below are all the files for a ready‑to‑run Electron desktop app. Put them in a new folder, keep the same structure, then run `npm install` and `npm start`.

---

## 📁 File Tree
```
.
├─ package.json
├─ main.js
├─ preload.js
├─ .gitignore
├─ assets/
│  ├─ icon.png              # (optional) app icon 512x512
│  └─ icon.icns             # (optional) macOS icon
└─ app/                     # your web game lives here
   ├─ index.html
   ├─ style.css
   ├─ script.js
   ├─ logo.png
   ├─ splash.mp3
   ├─ bg-music.mp3
   ├─ win.mp3
   ├─ draw.mp3
   └─ restart.mp3
```

> If you already have your game files, simply replace the files inside `app/` with your latest versions. The ones below are a working set that includes the splash screen, settings modal, sound system, theme toggle, scoreboard, best‑of‑N, and series history (with persistence).

---

## `package.json`
```json
{
  "name": "tic-tac-with-tashan",
  "version": "1.0.0",
  "description": "Tic Tac with Tashan – Electron desktop app",
  "main": "main.js",
  "author": "You",
  "license": "MIT",
  "scripts": {
    "start": "electron .",
    "dev": "electron .",
    "pack": "electron-builder --dir",
    "dist": "electron-builder"
  },
  "devDependencies": {
    "electron": "^31.0.0",
    "electron-builder": "^24.13.3"
  },
  "build": {
    "appId": "com.yourname.tictacwithtashan",
    "productName": "Tic Tac with Tashan",
    "files": [
      "app/**/*",
      "main.js",
      "preload.js",
      "package.json"
    ],
    "extraResources": [
      {
        "from": "assets/",
        "to": "assets",
        "filter": ["**/*"]
      }
    ],
    "mac": {
      "icon": "assets/icon.icns"
    },
    "win": {
      "icon": "assets/icon.png",
      "target": ["nsis", "portable"]
    },
    "linux": {
      "icon": "assets/icon.png",
      "target": ["AppImage", "deb"]
    }
  }
}
```

---

## `main.js`
```js
const { app, BrowserWindow, shell, nativeTheme } = require('electron');
const path = require('path');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1024,
    height: 768,
    minWidth: 820,
    minHeight: 600,
    backgroundColor: nativeTheme.shouldUseDarkColors ? '#111111' : '#f9f9f9',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.removeMenu();
  mainWindow.loadFile(path.join(__dirname, 'app', 'index.html'));

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => { mainWindow = null; });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
```

---

## `preload.js`
```js
// Minimal, but ready if you want to expose APIs later
const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('tashan', {
  version: '1.0.0'
});
```

---

## `.gitignore`
```gitignore
node_modules
/dist
/out
/build
.DS_Store
```

---

# 🕹 Web App (in `app/`)

## `app/index.html`
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tic Tac with Tashan</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body class="dark-theme">
  <!-- Splash Screen -->
  <div id="splash">
    <img src="logo.png" alt="Tic Tac with Tashan Logo" class="splash-logo" />
  </div>

  <!-- Main Game -->
  <div id="game" class="hidden">
    <div class="logo-container">
      <img src="logo.png" alt="Tic Tac with Tashan Logo" id="game-logo" class="game-logo" />
    </div>

    <!-- Mode -->
    <div id="game-mode">
      <label for="mode">Choose Mode:</label>
      <select id="mode">
        <option value="3">Best of 3</option>
        <option value="5" selected>Best of 5</option>
        <option value="7">Best of 7</option>
      </select>
    </div>

    <!-- Turn Indicator -->
    <div id="turn">Player X's Turn</div>

    <!-- Board -->
    <div id="board" class="board">
      <div class="cell" data-index="0"></div>
      <div class="cell" data-index="1"></div>
      <div class="cell" data-index="2"></div>
      <div class="cell" data-index="3"></div>
      <div class="cell" data-index="4"></div>
      <div class="cell" data-index="5"></div>
      <div class="cell" data-index="6"></div>
      <div class="cell" data-index="7"></div>
      <div class="cell" data-index="8"></div>
    </div>

    <!-- Settings -->
    <button id="open-settings">⚙️ Settings</button>

    <!-- Settings Modal -->
    <div id="settings-modal" class="modal">
      <div class="modal-content">
        <span id="close-settings" class="close">&times;</span>
        <h2>🎛️ Game Settings</h2>

        <button id="sound-toggle">🔊 Sound: ON</button>
        <br /><br />

        <label for="music-slider">🎶 Music Volume:</label>
        <input type="range" id="music-slider" min="0" max="1" step="0.1" value="0.6" />
        <br /><br />

        <label for="sfx-slider">🔔 SFX Volume:</label>
        <input type="range" id="sfx-slider" min="0" max="1" step="0.1" value="0.8" />
        <br /><br />

        <button id="reset-settings">🔄 Reset Sound Settings</button>
        <br /><br />
        <button id="theme-toggle">🌙 Dark Theme</button>
      </div>
    </div>

    <!-- Winner Modal -->
    <div id="winner-modal" class="modal">
      <div class="modal-content">
        <h2 id="winner-text">Player Wins!</h2>
        <div id="scoreboard">
          <p>❌ X Wins: <span id="score-x">0</span></p>
          <p>⭕ O Wins: <span id="score-o">0</span></p>
          <p>🤝 Draws: <span id="score-draw">0</span></p>
        </div>
        <button id="play-again">🔄 Play Again</button>
        <button id="reset-scores">🗑️ Reset Scores</button>
      </div>
    </div>

    <!-- Series History -->
    <div id="series-history">
      <h3>📜 Series History</h3>
      <ul id="history-list"></ul>
      <button id="clear-history">🗑 Clear History</button>
    </div>
  </div>

  <!-- Confetti Canvas -->
  <canvas id="confetti-canvas"></canvas>

  <!-- Sounds -->
  <audio id="win-sound" src="win.mp3"></audio>
  <audio id="draw-sound" src="draw.mp3"></audio>
  <audio id="restart-sound" src="restart.mp3"></audio>
  <audio id="splash-music" src="splash.mp3"></audio>
  <audio id="bg-music" src="bg-music.mp3" loop></audio>

  <script src="script.js"></script>
</body>
</html>
```

---

## `app/style.css`
```css
/* Base */
* { box-sizing: border-box; }
body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Inter, Arial, sans-serif; margin: 0; }
.hidden { display: none; }

/* Splash */
#splash { position: fixed; inset: 0; background: #000; display: flex; align-items: center; justify-content: center; z-index: 9999; }
.splash-logo { width: 360px; max-width: 90%; animation: zoomIn 1.5s ease; }
.fade-out { animation: fadeOut 1s forwards; }
@keyframes zoomIn { from { transform: scale(0.5); opacity: 0; } to { transform: scale(1); opacity: 1; } }
@keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }

/* Layout */
.logo-container { text-align: center; margin: 16px 0 8px; }
.game-logo { width: 280px; max-width: 90%; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.6); filter: drop-shadow(0 0 8px #ff0077); }
#turn { text-align: center; font-weight: 800; margin: 8px 0 12px; }

.board { width: min(92vw, 480px); aspect-ratio: 1/1; margin: 0 auto; display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
.cell { background: #222; border: 2px solid #ff0077; border-radius: 16px; display: flex; align-items: center; justify-content: center; font-size: clamp(40px, 10vw, 72px); font-weight: 900; user-select: none; height: 100%; transition: transform .08s ease, box-shadow .2s; }
.cell:active { transform: scale(0.98); }

/* Marks */
.board .x { color: #00ffcc; }
.board .o { color: #ff0077; }

/* Winning glow */
.cell.win { animation: glow 1s infinite alternate; }
@keyframes glow { from { box-shadow: 0 0 10px rgba(255,255,255,.4); transform: scale(1.05);} to { box-shadow: 0 0 24px rgba(255,255,255,1); transform: scale(1.1);} }
body.dark-theme .cell.x.win { box-shadow: 0 0 20px #00ffcc, inset 0 0 10px #00ffcc; }
body.dark-theme .cell.o.win { box-shadow: 0 0 20px #ff0077, inset 0 0 10px #ff0077; }

/* Settings button */
#open-settings { display: block; margin: 14px auto; background: #ff0077; color: #fff; border: none; padding: 10px 18px; border-radius: 8px; font-size: 16px; cursor: pointer; transition: background .3s; }
#open-settings:hover { background: #d60065; }

/* Modal */
.modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 10000; justify-content: center; align-items: center; }
.modal-content { background: #222; color: #fff; padding: 20px; border-radius: 12px; width: 320px; text-align: center; box-shadow: 0 0 20px rgba(255,0,119,0.5); animation: fadeIn .3s ease; }
@keyframes fadeIn { from { opacity: 0; transform: scale(.8);} to { opacity: 1; transform: scale(1);} }
.close { float: right; font-size: 22px; cursor: pointer; color: #fff; }
.close:hover { color: #ff0077; }

/* Scoreboard */
#scoreboard { margin: 12px 0; text-align: left; }
#scoreboard p { margin: 6px 0; }
#scoreboard span { font-weight: 800; color: #ff0077; }

/* History */
#series-history { width: min(92vw, 480px); margin: 18px auto; padding: 10px; background: rgba(0,0,0,0.4); border-radius: 10px; max-height: 220px; overflow-y: auto; }
#series-history h3 { margin: 0 0 8px; color: #ffd700; }
#history-list { list-style: none; margin: 0; padding: 0; }
#history-list li { padding: 6px 8px; border-bottom: 1px solid rgba(255,255,255,0.1); }
#clear-history { margin-top: 10px; background: #c62828; color: #fff; padding: 6px 12px; border: none; border-radius: 8px; cursor: pointer; }
#clear-history:hover { background: #ff1744; }

/* Light theme */
body.light-theme { background: #f9f9f9; color: #222; }
body.light-theme .cell { background: #fff; border: 2px solid #222; }
body.light-theme .board .x { color: #0077ff; }
body.light-theme .board .o { color: #ff6600; }
body.light-theme .modal-content { background: #fff; color: #222; box-shadow: 0 0 20px rgba(0,0,0,0.3); }
body.light-theme #open-settings { background: #222; color: #fff; }
body.light-theme #open-settings:hover { background: #444; }
body.light-theme #scoreboard span { color: #0077ff; }
body.light-theme #series-history { background: rgba(255,255,255,0.7); }
body.light-theme .game-logo { filter: drop-shadow(0 0 8px #222); }

/* Confetti Canvas */
#confetti-canvas { position: fixed; inset: 0; width: 100%; height: 100%; pointer-events: none; z-index: 9999; }
```

---

## `app/script.js`
```js
// ====== Elements ======
const cells = Array.from(document.querySelectorAll('.cell'));
const turnEl = document.getElementById('turn');
const boardEl = document.getElementById('board');
const winnerModal = document.getElementById('winner-modal');
const winnerText = document.getElementById('winner-text');
const playAgainBtn = document.getElementById('play-again');
const resetScoresBtn = document.getElementById('reset-scores');
const settingsModal = document.getElementById('settings-modal');
const openSettingsBtn = document.getElementById('open-settings');
const closeSettingsBtn = document.getElementById('close-settings');
const soundToggleBtn = document.getElementById('sound-toggle');
const musicSlider = document.getElementById('music-slider');
const sfxSlider = document.getElementById('sfx-slider');
const themeToggleBtn = document.getElementById('theme-toggle');
const clearHistoryBtn = document.getElementById('clear-history');

const scoreXEl = document.getElementById('score-x');
const scoreOEl = document.getElementById('score-o');
const scoreDrawEl = document.getElementById('score-draw');

const modeSelect = document.getElementById('mode');

const winSfx = document.getElementById('win-sound');
const drawSfx = document.getElementById('draw-sound');
const restartSfx = document.getElementById('restart-sound');
const splashMusic = document.getElementById('splash-music');
const bgMusic = document.getElementById('bg-music');

const confettiCanvas = document.getElementById('confetti-canvas');
const ctx = confettiCanvas.getContext('2d');

// ====== Game State ======
let currentPlayer = 'X';
let grid = Array(9).fill('');
let scoreX = 0, scoreO = 0, scoreDraw = 0;
let targetWins = parseInt(modeSelect.value) || 5; // Best of N (wins to clinch = ceil(N/2))
let soundEnabled = true;

// ====== Responsive canvas ======
function resizeCanvas(){
  confettiCanvas.width = window.innerWidth;
  confettiCanvas.height = window.innerHeight;
}
window.addEventListener('resize', resizeCanvas); resizeCanvas();

// ====== Splash Logic ======
window.addEventListener('load', () => {
  // Load persisted settings/history/theme first
  loadSettings();
  loadTheme();
  loadHistory();

  // Splash with music then reveal
  try { splashMusic.volume = parseFloat(localStorage.getItem('musicVolume') ?? '0.6'); } catch(e){}
  if (soundEnabled) splashMusic.play().catch(()=>{});

  setTimeout(() => {
    document.getElementById('splash').classList.add('fade-out');
    splashMusic.pause(); splashMusic.currentTime = 0;
    setTimeout(() => {
      document.getElementById('splash').style.display = 'none';
      document.getElementById('game').classList.remove('hidden');
      // Start bg music
      try { bgMusic.volume = parseFloat(localStorage.getItem('musicVolume') ?? '0.6'); } catch(e){}
      if (soundEnabled) bgMusic.play().catch(()=>{});
    }, 1000);
  }, 2000);
});

// ====== Board Interaction ======
function handleCellClick(e){
  const cell = e.target;
  const idx = parseInt(cell.getAttribute('data-index'));
  if (!Number.isInteger(idx)) return;
  if (grid[idx] || isGameOver()) return;

  grid[idx] = currentPlayer;
  cell.textContent = currentPlayer;
  cell.classList.add(currentPlayer.toLowerCase());

  const result = getResult(grid);
  if (result.winner){
    highlightWin(result.line);
    onWin(currentPlayer);
  } else if (grid.every(Boolean)){
    onDraw();
  } else {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    updateTurn();
  }
}

cells.forEach(c => c.addEventListener('click', handleCellClick));

function updateTurn(){
  turnEl.textContent = `Player ${currentPlayer}'s Turn`;
}

function isGameOver(){
  return !!document.querySelector('.cell.win');
}

function getResult(cells){
  const L = [ [0,1,2],[3,4,5],[6,7,8], [0,3,6],[1,4,7],[2,5,8], [0,4,8],[2,4,6] ];
  for (const line of L){
    const [a,b,c] = line;
    if (cells[a] && cells[a]===cells[b] && cells[a]===cells[c]){
      return { winner: cells[a], line };
    }
  }
  if (cells.every(Boolean)) return { winner: 'D', line: null };
  return { winner: null, line: null };
}

function highlightWin(line){
  line.forEach(i => cells[i].classList.add('win'));
}

function resetBoard(){
  grid = Array(9).fill('');
  cells.forEach(c => c.textContent='');
  cells.forEach(c => c.classList.remove('x','o','win'));
  currentPlayer = 'X';
  updateTurn();
}

// ====== Win/Draw handling ======
function onWin(player){
  if (player === 'X'){ scoreX++; scoreXEl.textContent = scoreX; } else { scoreO++; scoreOEl.textContent = scoreO; }
  if (soundEnabled){ try { winSfx.volume = parseFloat(localStorage.getItem('sfxVolume') ?? '0.8'); winSfx.play(); } catch(e){} }
  showWinner(`${player} Wins! 🎉`);
  startConfetti();
  checkChampion();
}

function onDraw(){
  scoreDraw++; scoreDrawEl.textContent = scoreDraw;
  if (soundEnabled){ try { drawSfx.volume = parseFloat(localStorage.getItem('sfxVolume') ?? '0.8'); drawSfx.play(); } catch(e){} }
  showWinner("It's a Draw 🤝");
}

function showWinner(text){
  winnerText.textContent = text;
  winnerModal.style.display = 'flex';
}

playAgainBtn.addEventListener('click', () => {
  winnerModal.style.display = 'none';
  if (soundEnabled){ try { restartSfx.volume = parseFloat(localStorage.getItem('sfxVolume') ?? '0.8'); restartSfx.play(); } catch(e){} }
  resetBoard();
});

resetScoresBtn.addEventListener('click', () => {
  scoreX = 0; scoreO = 0; scoreDraw = 0;
  scoreXEl.textContent = scoreX; scoreOEl.textContent = scoreO; scoreDrawEl.textContent = scoreDraw;
});

// ====== Best-of-N (tournament) ======
modeSelect.addEventListener('change', () => {
  targetWins = parseInt(modeSelect.value) || 5;
  resetTournament();
});

function checkChampion(){
  const need = Math.ceil(parseInt(modeSelect.value)/2);
  if (scoreX >= need){
    winnerText.textContent = `❌ X is the Champion! 🏆 (Best of ${modeSelect.value})`;
    startConfetti();
    persistSeries('X');
    setTimeout(resetTournament, 1200);
  } else if (scoreO >= need){
    winnerText.textContent = `⭕ O is the Champion! 🏆 (Best of ${modeSelect.value})`;
    startConfetti();
    persistSeries('O');
    setTimeout(resetTournament, 1200);
  }
}

function resetTournament(){
  // Save then clear scoreboard visuals
  scoreX = 0; scoreO = 0; scoreDraw = 0;
  scoreXEl.textContent = scoreX; scoreOEl.textContent = scoreO; scoreDrawEl.textContent = scoreDraw;
}

// ====== Series History (persistent) ======
let seriesCount = parseInt(localStorage.getItem('seriesCount') || '0');
const historyList = document.getElementById('history-list');
let savedHistory = JSON.parse(localStorage.getItem('seriesHistory') || '[]');

function loadHistory(){
  historyList.innerHTML = '';
  savedHistory.forEach(entry => {
    const li = document.createElement('li'); li.textContent = entry; historyList.appendChild(li);
  });
}

function persistSeries(winner){
  seriesCount += 1;
  const record = `Series ${seriesCount}: ${winner === 'X' ? '❌ X' : '⭕ O'} wins the series (${scoreX}-${scoreO}) (Best of ${modeSelect.value})`;
  savedHistory.unshift(record);
  localStorage.setItem('seriesHistory', JSON.stringify(savedHistory));
  localStorage.setItem('seriesCount', String(seriesCount));
  const li = document.createElement('li'); li.textContent = record; historyList.prepend(li);
}

clearHistoryBtn.addEventListener('click', () => {
  localStorage.removeItem('seriesHistory');
  localStorage.removeItem('seriesCount');
  savedHistory = []; seriesCount = 0; historyList.innerHTML='';
});

// ====== Settings: sound + theme (persistent) ======
function updateSoundButton(){
  soundToggleBtn.textContent = soundEnabled ? '🔊 Sound: ON' : '🔇 Sound: OFF';
}

function applyVolumes(){
  const musicVol = parseFloat(localStorage.getItem('musicVolume') ?? musicSlider.value);
  const sfxVol = parseFloat(localStorage.getItem('sfxVolume') ?? sfxSlider.value);
  splashMusic.volume = musicVol; bgMusic.volume = musicVol;
  winSfx.volume = sfxVol; drawSfx.volume = sfxVol; restartSfx.volume = sfxVol;
}

function loadSettings(){
  const savedSound = localStorage.getItem('soundEnabled');
  const savedMusicVol = localStorage.getItem('musicVolume');
  const savedSfxVol = localStorage.getItem('sfxVolume');
  if (savedSound !== null) soundEnabled = savedSound === 'true';
  if (savedMusicVol !== null) musicSlider.value = savedMusicVol;
  if (savedSfxVol !== null) sfxSlider.value = savedSfxVol;
  document.querySelectorAll('audio').forEach(a => a.muted = !soundEnabled);
  updateSoundButton();
  applyVolumes();
}

function saveSettings(){
  localStorage.setItem('soundEnabled', String(soundEnabled));
  localStorage.setItem('musicVolume', musicSlider.value);
  localStorage.setItem('sfxVolume', sfxSlider.value);
}

soundToggleBtn.addEventListener('click', () => {
  soundEnabled = !soundEnabled; updateSoundButton();
  document.querySelectorAll('audio').forEach(a => a.muted = !soundEnabled);
  saveSettings();
});

musicSlider.addEventListener('input', () => { applyVolumes(); saveSettings(); });

sfxSlider.addEventListener('input', () => { applyVolumes(); saveSettings(); });

// Theme
function saveTheme(theme){ localStorage.setItem('theme', theme); }
function applyDarkTheme(){ document.body.classList.remove('light-theme'); document.body.classList.add('dark-theme'); themeToggleBtn.textContent='☀️ Light Theme'; saveTheme('dark'); }
function applyLightTheme(){ document.body.classList.remove('dark-theme'); document.body.classList.add('light-theme'); themeToggleBtn.textContent='🌙 Dark Theme'; saveTheme('light'); }
function loadTheme(){ const t = localStorage.getItem('theme') || 'dark'; (t==='light'?applyLightTheme():applyDarkTheme()); }

themeToggleBtn.addEventListener('click', () => {
  if (document.body.classList.contains('dark-theme')) applyLightTheme(); else applyDarkTheme();
});

// ====== Settings Modal ======
openSettingsBtn.addEventListener('click', () => { settingsModal.style.display='flex'; });
closeSettingsBtn.addEventListener('click', () => { settingsModal.style.display='none'; });
window.addEventListener('click', (e) => { if (e.target === settingsModal) settingsModal.style.display='none'; });

// ====== Confetti ======
let confetti = [];
function createConfetti(){
  const colors = ['#ff0077','#00ffcc','#ff6600','#0077ff','#ffff00'];
  for (let i=0;i<150;i++){
    confetti.push({ x: Math.random()*confettiCanvas.width, y: Math.random()*-confettiCanvas.height, r: Math.random()*6+2, d: Math.random()*0.5+0.5, color: colors[Math.floor(Math.random()*colors.length)], tilt: Math.random()*10-10, tiltAngleIncrement: Math.random()*0.07+0.05, tiltAngle: 0 });
  }
}
function drawConfetti(){
  ctx.clearRect(0,0,confettiCanvas.width, confettiCanvas.height);
  confetti.forEach((c,i)=>{ ctx.beginPath(); ctx.lineWidth = c.r; ctx.strokeStyle = c.color; ctx.moveTo(c.x + c.tilt + c.r/2, c.y); ctx.lineTo(c.x + c.tilt, c.y + c.tilt + c.r/2); ctx.stroke(); });
  updateConfetti();
}
function updateConfetti(){
  confetti.forEach((c,i)=>{ c.tiltAngle += c.tiltAngleIncrement; c.y += (Math.cos(c.d)+3+c.r/2)/2; c.x += Math.sin(c.d); c.tilt = Math.sin(c.tiltAngle - i/3)*15; if (c.y > confettiCanvas.height){ confetti[i] = { ...c, x: Math.random()*confettiCanvas.width, y: -20 }; } });
}
function startConfetti(){
  createConfetti(); const duration = 2000; const end = Date.now()+duration;
  (function frame(){ drawConfetti(); if (Date.now()<end){ requestAnimationFrame(frame); } else { confetti=[]; ctx.clearRect(0,0,confettiCanvas.width, confettiCanvas.height); } })();
}

// Init
updateTurn();
```

---

## 🔊 Media files (placeholders)
- `app/logo.png` – your glossy logo
- `app/splash.mp3` – short intro sting (2–4s)
- `app/bg-music.mp3` – looping background track
- `app/win.mp3`, `app/draw.mp3`, `app/restart.mp3` – SFX

You can replace these with your own files or keep the names and add your media later.

---

# ▶️ Run it
1) In this folder: `npm install`
2) Start the app: `npm start`
3) Optional builds: `npm run dist` (creates installers in `dist/`)

> If code signing is required for macOS/Windows, configure signing in `electron-builder` docs.
(function(){
  const cells = Array.from(document.querySelectorAll('.cell'));
  const statusEl = document.getElementById('status');
  const turnIndicator = document.getElementById('turn-indicator');
  const pvpBtn = document.getElementById('pvp-btn');
  const cpuBtn = document.getElementById('cpu-btn');
  const newRoundBtn = document.getElementById('new-round');
  const resetScoresBtn = document.getElementById('reset-scores');
  const swapStartBtn = document.getElementById('swap-start');
  const scoreXEl = document.getElementById('score-x');
  const scoreOEl = document.getElementById('score-o');
  const scoreTieEl = document.getElementById('score-tie');
  const difficultySel = document.getElementById('difficulty');
  const undoBtn = document.getElementById('undo');
  const seeRulesBtn = document.getElementById('see-rules');

  let gameActive = true;
  let boardState = Array(9).fill('');
  let currentPlayer = 'X';
  let startingPlayer = 'X';
  let scores = {X:0,O:0,T:0};
  let vsCPU = false;
  let lastMove = null;
  let undoAvailable = true;

  const winConditions = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];

  function setStatus(text){statusEl.textContent=text;}
  function updateTurnIndicator(){turnIndicator.textContent=currentPlayer;}
  function renderBoard(){
    cells.forEach((c,i)=>{
      c.className='cell';
      if(boardState[i]){c.textContent=boardState[i];c.classList.add(boardState[i].toLowerCase(),'disabled');}
      else c.textContent='';
    });
  }
  function checkWinner(state=boardState){
    for(let wc of winConditions){
      const[a,b,c]=wc;
      if(state[a]&&state[a]===state[b]&&state[b]===state[c]) return{winner:state[a],line:wc};
    }
    if(state.every(s=>s))return{winner:'T'};
    return null;
  }
  function highlightWin(line){line.forEach(i=>cells[i].classList.add('win'));}
  function endGame(res){
    gameActive=false;
    if(res.winner==='T'){scores.T++;scoreTieEl.textContent=scores.T;setStatus("It's a tie!");}
    else{scores[res.winner]++;scoreXEl.textContent=scores.X;scoreOEl.textContent=scores.O;setStatus(`${res.winner} wins!`);highlightWin(res.line);}
    undoBtn.disabled=true;
  }
  function makeMove(i,p){
    if(!gameActive||boardState[i])return;
    boardState[i]=p;lastMove={i,p};undoAvailable=true;undoBtn.disabled=false;renderBoard();cells[i].classList.add('pop');
    let res=checkWinner();if(res){endGame(res);return;}
    currentPlayer=p==='X'?'O':'X';updateTurnIndicator();setStatus(`${currentPlayer}'s turn`);
  }
  function getEmpty(state=boardState){return state.map((v,i)=>!v?i:-1).filter(i=>i>=0);}
  function findCritical(state,mark){
    for(const wc of winConditions){
      const[a,b,c]=wc;const vals=[state[a],state[b],state[c]];
      if(vals.filter(v=>v===mark).length===2&&vals.includes(''))return wc.find(idx=>!state[idx]);
    }return null;
  }
  function minimax(state,player){
    const avail=getEmpty(state);const win=checkWinner(state);
    if(win){if(win.winner==='X')return{score:-10};if(win.winner==='O')return{score:10};return{score:0};}
    const moves=[];
    for(const i of avail){const move={i};state[i]=player;
      move.score=minimax(state,player==='O'?'X':'O').score;state[i]='';moves.push(move);}
    return player==='O'?moves.reduce((a,b)=>a.score>b.score?a:b):moves.reduce((a,b)=>a.score<b.score?a:b);
  }
  function cpuMove(){
    if(!gameActive)return;const empty=getEmpty();let move;
    const diff=difficultySel.value;
    if(diff==='easy')move=empty[Math.random()*empty.length|0];
    else if(diff==='medium'){move=findCritical(boardState,'O')??findCritical(boardState,'X')??(boardState[4]===''?4:empty[Math.random()*empty.length|0]);}
    else move=boardState.every(v=>!v)?4:(minimax([...boardState],'O').i);
    setTimeout(()=>makeMove(move,'O'),300);
  }

  cells.forEach((c,i)=>c.addEventListener('click',()=>{if(!vsCPU||currentPlayer==='X'){makeMove(i,currentPlayer);if(vsCPU&&gameActive&&currentPlayer==='O')cpuMove();}}));
  pvpBtn.onclick=()=>{vsCPU=false;pvpBtn.classList.add('active');cpuBtn.classList.remove('active');};
  cpuBtn.onclick=()=>{vsCPU=true;cpuBtn.classList.add('active');pvpBtn.classList.remove('active');if(vsCPU&&currentPlayer==='O')cpuMove();};
  newRoundBtn.onclick=()=>{startingPlayer=startingPlayer==='X'?'O':'X';boardState.fill('');gameActive=true;currentPlayer=startingPlayer;renderBoard();setStatus(`${currentPlayer} starts`);updateTurnIndicator();};
  resetScoresBtn.onclick=()=>{scores={X:0,O:0,T:0};scoreXEl.textContent=0;scoreOEl.textContent=0;scoreTieEl.textContent=0;};
  swapStartBtn.onclick=()=>{startingPlayer=startingPlayer==='X'?'O':'X';currentPlayer=startingPlayer;setStatus(`Starter: ${currentPlayer}`);};
  undoBtn.onclick=()=>{if(undoAvailable&&lastMove){boardState[lastMove.i]='';lastMove=null;undoAvailable=false;undoBtn.disabled=true;renderBoard();}};
  seeRulesBtn.onclick=()=>alert("Rules:\n- Get 3 in a row to win\n- Tie if board fills\n- Play vs CPU with 3 difficulty levels");
  renderBoard();setStatus("Make a move — X starts");
})();
const boardElement = document.getElementById("board");
const twoPlayerBtn = document.getElementById("twoPlayerBtn");
const cpuBtn = document.getElementById("cpuBtn");
const difficultySelect = document.getElementById("difficulty");
const undoBtn = document.getElementById("undoBtn");
const swapBtn = document.getElementById("swapBtn");
const resetBtn = document.getElementById("resetBtn");
const rulesBtn = document.getElementById("rulesBtn");
const rulesPopup = document.getElementById("rulesPopup");
const closeRules = document.getElementById("closeRules");

const playerXScore = document.getElementById("playerXScore");
const playerOScore = document.getElementById("playerOScore");

let currentPlayer = "X";
let board = ["", "", "", "", "", "", "", "", ""];
let history = [];
let scores = { X: 0, O: 0 };
let cpuMode = false;
let cpuDifficulty = "easy";
let starter = "X";

function renderBoard() {
  boardElement.innerHTML = "";
  board.forEach((val, i) => {
    const cell = document.createElement("div");
    cell.classList.add("cell");
    cell.textContent = val;
    cell.addEventListener("click", () => makeMove(i));
    boardElement.appendChild(cell);
  });
}

function makeMove(index) {
  if (board[index] || checkWinner()) return;

  board[index] = currentPlayer;
  history.push(index);
  renderBoard();

  if (checkWinner()) {
    alert(`${currentPlayer} Wins!`);
    scores[currentPlayer]++;
    updateScores();
    resetBoard();
    return;
  }

  if (board.every(cell => cell)) {
    alert("It's a Draw!");
    resetBoard();
    return;
  }

  currentPlayer = currentPlayer === "X" ? "O" : "X";

  if (cpuMode && currentPlayer === "O") {
    cpuMove();
  }
}

function cpuMove() {
  let move;
  if (cpuDifficulty === "easy") {
    const empty = board.map((v, i) => (v === "" ? i : null)).filter(v => v !== null);
    move = empty[Math.floor(Math.random() * empty.length)];
  } else if (cpuDifficulty === "medium") {
    move = findWinningMove("O") || findWinningMove("X") || randomMove();
  } else {
    move = minimax(board, "O").index;
  }
  makeMove(move);
}

function findWinningMove(player) {
  const winPatterns = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];
  for (let pattern of winPatterns) {
    const [a,b,c] = pattern;
    if (board[a] === player && board[b] === player && !board[c]) return c;
    if (board[a] === player && board[c] === player && !board[b]) return b;
    if (board[b] === player && board[c] === player && !board[a]) return a;
  }
  return null;
}

function randomMove() {
  const empty = board.map((v, i) => (v === "" ? i : null)).filter(v => v !== null);
  return empty[Math.floor(Math.random() * empty.length)];
}

function minimax(newBoard, player) {
  const availSpots = newBoard.map((v, i) => (v === "" ? i : null)).filter(v => v !== null);
  if (checkWin(newBoard, "X")) return { score: -10 };
  if (checkWin(newBoard, "O")) return { score: 10 };
  if (availSpots.length === 0) return { score: 0 };

  const moves = [];
  for (let i of availSpots) {
    const move = {};
    move.index = i;
    newBoard[i] = player;

    if (player === "O") {
      const result = minimax(newBoard, "X");
      move.score = result.score;
    } else {
      const result = minimax(newBoard, "O");
      move.score = result.score;
    }
    newBoard[i] = "";
    moves.push(move);
  }

  let bestMove;
  if (player === "O") {
    let bestScore = -Infinity;
    for (let m of moves) {
      if (m.score > bestScore) {
        bestScore = m.score;
        bestMove = m;
      }
    }
  } else {
    let bestScore = Infinity;
    for (let m of moves) {
      if (m.score < bestScore) {
        bestScore = m.score;
        bestMove = m;
      }
    }
  }
  return bestMove;
}

function checkWin(b, player) {
  const winPatterns = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];
  return winPatterns.some(pattern => pattern.every(i => b[i] === player));
}

function checkWinner() {
  return checkWin(board, "X") || checkWin(board, "O");
}

function updateScores() {
  playerXScore.textContent = `X: ${scores.X}`;
  playerOScore.textContent = `O: ${scores.O}`;
}

function resetBoard() {
  board = ["", "", "", "", "", "", "", "", ""];
  history = [];
  currentPlayer = starter;
  renderBoard();
}

undoBtn.addEventListener("click", () => {
  if (!history.length) return;
  const last = history.pop();
  board[last] = "";
  currentPlayer = currentPlayer === "X" ? "O" : "X";
  renderBoard();
});

swapBtn.addEventListener("click", () => {
  starter = starter === "X" ? "O" : "X";
  alert(`Starter swapped! ${starter} goes first next round.`);
  resetBoard();
});

resetBtn.addEventListener("click", () => {
  scores = { X: 0, O: 0 };
  updateScores();
  resetBoard();
});

rulesBtn.addEventListener("click", () => {
  rulesPopup.classList.remove("hidden");
});

closeRules.addEventListener("click", () => {
  rulesPopup.classList.add("hidden");
});

twoPlayerBtn.addEventListener("click", () => {
  cpuMode = false;
  difficultySelect.style.display = "none";
  resetBoard();
});

cpuBtn.addEventListener("click", () => {
  cpuMode = true;
  difficultySelect.style.display = "inline-block";
  resetBoard();
});

difficultySelect.addEventListener("change", e => {
  cpuDifficulty = e.target.value;
});

renderBoard();
updateScores();
# Full working script.js content
script_js = """const board = document.getElementById("board");
const twoPlayerBtn = document.getElementById("twoPlayerBtn");
const cpuBtn = document.getElementById("cpuBtn");
const difficultySelect = document.getElementById("difficulty");
const undoBtn = document.getElementById("undoBtn");
const swapBtn = document.getElementById("swapBtn");
const resetBtn = document.getElementById("resetBtn");
const rulesBtn = document.getElementById("rulesBtn");
const rulesPopup = document.getElementById("rulesPopup");
const closeRules = document.getElementById("closeRules");

let cells = [];
let currentPlayer = "X";
let gameMode = "2p";
let moves = [];
let scores = { X: 0, O: 0 };
let starter = "X";

function initBoard() {
  board.innerHTML = "";
  cells = [];
  for (let i = 0; i < 9; i++) {
    const cell = document.createElement("div");
    cell.classList.add("cell");
    cell.addEventListener("click", () => makeMove(i));
    board.appendChild(cell);
    cells.push(cell);
  }
}

function makeMove(i) {
  if (cells[i].textContent !== "") return;
  cells[i].textContent = currentPlayer;
  moves.push(i);

  if (checkWin(currentPlayer)) {
    alert(currentPlayer + " wins!");
    scores[currentPlayer]++;
    updateScoreboard();
    initBoard();
    currentPlayer = starter;
    return;
  }

  if (moves.length === 9) {
    alert("It's a draw!");
    initBoard();
    currentPlayer = starter;
    return;
  }

  currentPlayer = currentPlayer === "X" ? "O" : "X";

  if (gameMode === "cpu" && currentPlayer === "O") {
    cpuMove();
  }
}

function cpuMove() {
  let move;
  const difficulty = difficultySelect.value;
  if (difficulty === "easy") {
    const emptyCells = cells.map((c, i) => (c.textContent === "" ? i : null)).filter(i => i !== null);
    move = emptyCells[Math.floor(Math.random() * emptyCells.length)];
  } else if (difficulty === "medium") {
    move = findWinningMove("O") || findWinningMove("X") || randomMove();
  } else {
    move = minimax(cells.map(c => c.textContent), "O").index;
  }
  makeMove(move);
}

function findWinningMove(player) {
  for (let i = 0; i < 9; i++) {
    if (cells[i].textContent === "") {
      cells[i].textContent = player;
      if (checkWin(player)) {
        cells[i].textContent = "";
        return i;
      }
      cells[i].textContent = "";
    }
  }
  return null;
}

function randomMove() {
  const emptyCells = cells.map((c, i) => (c.textContent === "" ? i : null)).filter(i => i !== null);
  return emptyCells[Math.floor(Math.random() * emptyCells.length)];
}

function minimax(newBoard, player) {
  const availSpots = newBoard.map((c, i) => (c === "" ? i : null)).filter(i => i !== null);
  if (checkWinOnBoard(newBoard, "X")) return { score: -10 };
  if (checkWinOnBoard(newBoard, "O")) return { score: 10 };
  if (availSpots.length === 0) return { score: 0 };

  const movesList = [];
  for (let i = 0; i < availSpots.length; i++) {
    const move = {};
    move.index = availSpots[i];
    newBoard[availSpots[i]] = player;

    if (player === "O") {
      const result = minimax(newBoard, "X");
      move.score = result.score;
    } else {
      const result = minimax(newBoard, "O");
      move.score = result.score;
    }

    newBoard[availSpots[i]] = "";
    movesList.push(move);
  }

  let bestMove;
  if (player === "O") {
    let bestScore = -10000;
    for (let i = 0; i < movesList.length; i++) {
      if (movesList[i].score > bestScore) {
        bestScore = movesList[i].score;
        bestMove = i;
      }
    }
  } else {
    let bestScore = 10000;
    for (let i = 0; i < movesList.length; i++) {
      if (movesList[i].score < bestScore) {
        bestScore = movesList[i].score;
        bestMove = i;
      }
    }
  }
  return movesList[bestMove];
}

function checkWin(player) {
  return checkWinOnBoard(cells.map(c => c.textContent), player);
}

function checkWinOnBoard(boardArr, player) {
  const winPatterns = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];
  return winPatterns.some(pattern => pattern.every(i => boardArr[i] === player));
}

function updateScoreboard() {
  document.getElementById("playerXScore").textContent = "X: " + scores.X;
  document.getElementById("playerOScore").textContent = "O: " + scores.O;
}

undoBtn.addEventListener("click", () => {
  if (moves.length === 0) return;
  const lastMove = moves.pop();
  cells[lastMove].textContent = "";
  currentPlayer = currentPlayer === "X" ? "O" : "X";
});

swapBtn.addEventListener("click", () => {
  starter = starter === "X" ? "O" : "X";
  alert("Starter swapped to " + starter);
});

resetBtn.addEventListener("click", () => {
  scores = { X: 0, O: 0 };
  updateScoreboard();
});

rulesBtn.addEventListener("click", () => {
  rulesPopup.classList.remove("hidden");
});

closeRules.addEventListener("click", () => {
  rulesPopup.classList.add("hidden");
});

twoPlayerBtn.addEventListener("click", () => {
  gameMode = "2p";
  difficultySelect.style.display = "none";
  initBoard();
});

cpuBtn.addEventListener("click", () => {
  gameMode = "cpu";
  difficultySelect.style.display = "inline-block";
  initBoard();
});

// Init on load
initBoard();
updateScoreboard();"""

# Overwrite script.js with full content
with open("/mnt/data/script.js", "w") as f:
    f.write(script_js)

# Repack zip with updated script.js
zip_path = "/mnt/data/tashan_tic_tac_toe.zip"
import zipfile
with zipfile.ZipFile(zip_path, "w") as zipf:
    zipf.write("/mnt/data/index.html", "index.html")
    zipf.write("/mnt/data/style.css", "style.css")
    zipf.write("/mnt/data/script.js", "script.js")

zip_path
